# Social Midei Studio Android build files

These are integration templates, not a completed build of the existing app.

## Before using
1. Merge these files into the existing repository; do not overwrite project-specific settings blindly.
2. Confirm the actual package/application ID and launcher Activity from the existing source.
3. Set `namespace` and `applicationId` to the app's existing values. `applicationId` must match the Firebase Android app registration used by `google-services.json`.
4. Place the matching Firebase config at `app/google-services.json`. If the project does not use Firebase yet, remove the Google Services plugin and Firebase dependencies.
5. Keep the existing Gradle wrapper scripts (`gradlew`, `gradlew.bat`) and wrapper JAR. Generate them with `gradle wrapper` if missing.
6. Ensure `app/src/main/.../MainActivity.kt` exists and matches the manifest activity.
7. Preserve the current app's dependencies, Compose setup, SDK levels, and version code; these sample values may need adapting.

## GitHub Actions signing secrets
For a signed release APK, add these repository Actions secrets:
- `ANDROID_KEYSTORE_BASE64`: base64-encoded JKS/keystore file
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Never commit a keystore, passwords, or `google-services.json` if your repository policy treats it as sensitive. Back up the release keystore securely: future app updates must use the same signing identity. The debug APK is signed with Android's generated debug key and is for testing only.

## Local build
```bash
./gradlew assembleDebug
```
Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

## Important
The debug variant above adds `.debug` to the application ID, so it can be installed alongside the production app but cannot update/replace it. Remove `applicationIdSuffix` if you specifically need an in-place debug upgrade and understand the signing implications.
