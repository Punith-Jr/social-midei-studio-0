# Add app-specific keep rules here.
# Firebase/Android libraries publish consumer rules; avoid broad keep-all rules.
