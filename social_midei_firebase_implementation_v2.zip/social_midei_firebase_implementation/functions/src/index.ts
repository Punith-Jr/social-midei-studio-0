import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";

initializeApp();
const db = getFirestore();

/**
 * Server-authoritative soft delete. Metadata is copied to trash and the image
 * record is marked deleted in one Firestore transaction. Storage bytes are
 * intentionally retained for recoverability; a scheduled retention job can
 * permanently purge them after your chosen retention period.
 */
export const moveImageToTrash = onCall(async (request) => {
  const uid = request.auth?.uid;
  if (!uid) throw new HttpsError("unauthenticated", "Sign in required.");

  const imageId = String(request.data?.imageId ?? "");
  if (!imageId || imageId.length > 150) {
    throw new HttpsError("invalid-argument", "A valid imageId is required.");
  }

  const imageRef = db.collection("images").doc(imageId);
  const trashRef = db.collection("trash").doc(imageId);

  await db.runTransaction(async (tx) => {
    const image = await tx.get(imageRef);
    if (!image.exists) throw new HttpsError("not-found", "Image not found.");
    const data = image.data()!;
    if (data.ownerUid !== uid) throw new HttpsError("permission-denied", "Not your image.");
    if (data.deletedAt) return;

    tx.set(trashRef, {
      ...data,
      ownerUid: uid,
      originalImageId: imageId,
      trashedAt: FieldValue.serverTimestamp()
    });
    tx.update(imageRef, {
      deletedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });
  });

  return { ok: true, imageId };
});

export const restoreImageFromTrash = onCall(async (request) => {
  const uid = request.auth?.uid;
  if (!uid) throw new HttpsError("unauthenticated", "Sign in required.");

  const imageId = String(request.data?.imageId ?? "");
  if (!imageId || imageId.length > 150) {
    throw new HttpsError("invalid-argument", "A valid imageId is required.");
  }

  const trashRef = db.collection("trash").doc(imageId);
  const imageRef = db.collection("images").doc(imageId);

  await db.runTransaction(async (tx) => {
    const trash = await tx.get(trashRef);
    if (!trash.exists) throw new HttpsError("not-found", "Trash item not found.");
    const data = trash.data()!;
    if (data.ownerUid !== uid) throw new HttpsError("permission-denied", "Not your item.");

    const restored = { ...data };
    delete restored.trashedAt;
    delete restored.originalImageId;
    restored.deletedAt = null;
    restored.updatedAt = FieldValue.serverTimestamp();

    tx.set(imageRef, restored);
    tx.delete(trashRef);
  });

  return { ok: true, imageId };
});
