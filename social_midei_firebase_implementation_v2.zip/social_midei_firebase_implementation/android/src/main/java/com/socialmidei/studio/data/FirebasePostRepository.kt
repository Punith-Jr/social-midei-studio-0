package com.socialmidei.studio.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await

class FirebasePostRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) : PostRepository {

    private val posts get() = db.collection("posts")

    private fun currentUid(): String = auth.currentUser?.uid
        ?: throw IllegalStateException("Sign in is required.")

    override suspend fun createPost(
        text: String,
        imageUrls: List<String>
    ): PostItem {
        val uid = currentUid()
        require(text.isNotBlank() || imageUrls.isNotEmpty()) {
            "A post must contain text or at least one image."
        }
        require(imageUrls.size <= 10) { "A post can contain at most 10 images." }

        val ref = posts.document()
        val data = mapOf(
            "ownerUid" to uid,
            "text" to text.trim(),
            "imageUrls" to imageUrls,
            "visibility" to "public",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        ref.set(data).await()
        val saved = ref.get().await()
        return saved.toObject(PostItem::class.java)?.copy(id = saved.id)
            ?: throw IllegalStateException("Post was saved but could not be read.")
    }

    override suspend fun getMyPostsPage(
        limit: Long,
        cursor: com.google.firebase.firestore.DocumentSnapshot?
    ): Page<PostItem> {
        require(limit in 1..100) { "Page size must be between 1 and 100." }
        var query: Query = posts
            .whereEqualTo("ownerUid", currentUid())
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
        if (cursor != null) query = query.startAfter(cursor)

        val snapshot = query.get().await()
        val items = snapshot.documents.mapNotNull { doc ->
            doc.toObject(PostItem::class.java)?.copy(id = doc.id)
        }
        return Page(
            items = items,
            nextCursor = snapshot.documents.lastOrNull(),
            hasMore = snapshot.size() == limit.toInt()
        )
    }

    override suspend fun updatePost(
        postId: String,
        text: String,
        imageUrls: List<String>
    ) {
        require(text.isNotBlank() || imageUrls.isNotEmpty()) {
            "A post must contain text or at least one image."
        }
        require(imageUrls.size <= 10) { "A post can contain at most 10 images." }

        val uid = currentUid()
        val ref = posts.document(postId)
        val existing = ref.get().await()
        require(existing.exists()) { "Post not found." }
        require(existing.getString("ownerUid") == uid) { "You do not own this post." }

        ref.update(
            mapOf(
                "text" to text.trim(),
                "imageUrls" to imageUrls,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    override suspend fun deletePost(postId: String) {
        val uid = currentUid()
        val ref = posts.document(postId)
        val existing = ref.get().await()
        require(existing.exists()) { "Post not found." }
        require(existing.getString("ownerUid") == uid) { "You do not own this post." }
        ref.delete().await()
    }
}
