package com.socialmidei.studio.data

import com.google.firebase.firestore.DocumentSnapshot

interface PostRepository {
    suspend fun createPost(text: String, imageUrls: List<String> = emptyList()): PostItem
    suspend fun getMyPostsPage(
        limit: Long = 30,
        cursor: DocumentSnapshot? = null
    ): Page<PostItem>
    suspend fun updatePost(postId: String, text: String, imageUrls: List<String>)
    suspend fun deletePost(postId: String)
}
