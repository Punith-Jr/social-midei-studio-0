package com.socialmidei.studio.data

import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirebaseImageRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) : ImageRepository {

    private val images get() = db.collection("images")
    private fun uid(): String = auth.currentUser?.uid
        ?: throw IllegalStateException("Sign in is required.")

    override suspend fun uploadProfileImage(uri: Uri, fileName: String): ImageItem =
        upload(uri, fileName, "profile")

    override suspend fun uploadPostImage(uri: Uri, fileName: String): ImageItem =
        upload(uri, fileName, "posts")

    private suspend fun upload(uri: Uri, fileName: String, category: String): ImageItem {
        val owner = uid()
        val id = UUID.randomUUID().toString()
        val path = "users/$owner/$category/$id"
        val ref = storage.reference.child(path)
        val contentType = "image/*"

        ref.putFile(uri).await()
        val url = ref.downloadUrl.await().toString()
        val now = Timestamp.now()
        val item = ImageItem(
            id = id,
            ownerUid = owner,
            storagePath = path,
            downloadUrl = url,
            fileName = fileName,
            contentType = contentType,
            createdAt = now,
            updatedAt = now
        )
        try {
            images.document(id).set(
                mapOf(
                    "ownerUid" to owner,
                    "storagePath" to path,
                    "downloadUrl" to url,
                    "fileName" to fileName,
                    "contentType" to contentType,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                    "deletedAt" to null
                )
            ).await()
        } catch (t: Throwable) {
            // Avoid leaving an orphaned Storage object if metadata creation fails.
            runCatching { ref.delete().await() }
            throw t
        }
        return item
    }

    override suspend fun getImagesPage(
        limit: Long,
        cursor: com.google.firebase.firestore.DocumentSnapshot?
    ): Page<ImageItem> {
        require(limit in 1..100) { "Page size must be between 1 and 100." }
        val owner = uid()
        var query: Query = images
            .whereEqualTo("ownerUid", owner)
            .whereEqualTo("deletedAt", null)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit)
        if (cursor != null) query = query.startAfter(cursor)

        val snapshot = query.get().await()
        val items = snapshot.documents.mapNotNull { doc ->
            doc.toObject(ImageItem::class.java)?.copy(id = doc.id)
        }
        return Page(
            items = items,
            nextCursor = snapshot.documents.lastOrNull(),
            hasMore = snapshot.size() == limit.toInt()
        )
    }

    override suspend fun deleteUserImage(imageId: String) {
        val owner = uid()
        val docRef = images.document(imageId)
        val snap = docRef.get().await()
        require(snap.exists()) { "Image not found." }
        require(snap.getString("ownerUid") == owner) { "You do not own this image." }

        val path = snap.getString("storagePath")
            ?: throw IllegalStateException("Image storage path is missing.")
        val trashRef = db.collection("trash").document(imageId)

        // Save metadata for restore, then mark source record deleted.
        val metadata = snap.data ?: emptyMap<String, Any>()
        db.runBatch { batch ->
            batch.set(trashRef, metadata + mapOf(
                "ownerUid" to owner,
                "originalImageId" to imageId,
                "trashedAt" to FieldValue.serverTimestamp()
            ))
            batch.update(docRef, mapOf(
                "deletedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ))
        }.await()

        // Keep the Storage object during the trash-retention period so restore works.
        // A trusted server-side purge job should permanently delete expired trash.
    }

    override suspend fun restoreUserImage(imageId: String) {
        val owner = uid()
        val trashRef = db.collection("trash").document(imageId)
        val trash = trashRef.get().await()
        require(trash.exists()) { "Trash item not found." }
        require(trash.getString("ownerUid") == owner) { "You do not own this item." }

        val data = trash.data ?: throw IllegalStateException("Trash metadata is empty.")
        val imageRef = images.document(imageId)
        // Metadata-only restore. If the Storage object was deleted, the app must
        // upload the original local file again and update storagePath/downloadUrl.
        db.runBatch { batch ->
            batch.set(imageRef, data - setOf("trashedAt", "originalImageId") + mapOf(
                "deletedAt" to null,
                "updatedAt" to FieldValue.serverTimestamp()
            ))
            batch.delete(trashRef)
        }.await()
    }
}
