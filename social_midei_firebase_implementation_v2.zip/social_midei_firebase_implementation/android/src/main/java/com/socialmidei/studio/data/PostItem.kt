package com.socialmidei.studio.data

import com.google.firebase.Timestamp

data class PostItem(
    val id: String = "",
    val ownerUid: String = "",
    val text: String = "",
    val imageUrls: List<String> = emptyList(),
    val visibility: String = "public",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)
