package com.socialmidei.studio.data

import android.net.Uri

interface ImageRepository {
    suspend fun uploadProfileImage(uri: Uri, fileName: String): ImageItem
    suspend fun uploadPostImage(uri: Uri, fileName: String): ImageItem
    suspend fun getImagesPage(limit: Long = 30, cursor: com.google.firebase.firestore.DocumentSnapshot? = null): Page<ImageItem>
    suspend fun deleteUserImage(imageId: String)
    suspend fun restoreUserImage(imageId: String)
}
