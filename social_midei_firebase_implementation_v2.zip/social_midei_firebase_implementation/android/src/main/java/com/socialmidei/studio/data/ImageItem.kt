package com.socialmidei.studio.data

import com.google.firebase.Timestamp

data class ImageItem(
    val id: String = "",
    val ownerUid: String = "",
    val storagePath: String = "",
    val downloadUrl: String = "",
    val fileName: String = "",
    val contentType: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null,
    val deletedAt: Timestamp? = null
)

data class Page<T>(
    val items: List<T>,
    val nextCursor: com.google.firebase.firestore.DocumentSnapshot?,
    val hasMore: Boolean
)
