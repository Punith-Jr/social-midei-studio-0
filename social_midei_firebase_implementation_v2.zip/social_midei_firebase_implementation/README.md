# Social Midei Studio — Kotlin + Firebase implementation starter

This is a **drop-in starter package**, not yet integrated into your GitHub repository.
It provides a Kotlin repository layer, Firestore/Storage rules, indexes, and Firebase
Cloud Functions for user-owned media records with cursor pagination and soft-delete/restore.

## Assumptions
- Android app uses Kotlin, coroutines, Firebase Authentication, Cloud Firestore and Firebase Storage.
- Firebase BoM / SDK versions are managed by the app's Gradle files.
- Firestore collections: `users`, `images`, `posts`, `trash`.
- Image metadata documents use the same ID as the Storage object ID.
- All operations require an authenticated Firebase user.

## Android dependencies
Add compatible versions (prefer Firebase BoM in your app):
```kotlin
implementation(platform("com.google.firebase:firebase-bom:<current-bom-version>"))
implementation("com.google.firebase:firebase-auth")
implementation("com.google.firebase:firebase-firestore")
implementation("com.google.firebase:firebase-storage")
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:<compatible-version>")
```

## Add the Kotlin files
Copy `android/src/main/java/...` into your app's source tree. Change the package
`com.socialmidei.studio.data` to match your application namespace.

## Firebase setup
1. Enable Authentication providers used by your app.
2. Create a Firestore database and Storage bucket.
3. Deploy `firestore.rules`, `storage.rules`, and `firestore.indexes.json`.
4. In `functions/`, run `npm install`, then `npm run build`, then deploy Functions.
5. Configure Firebase App Check before production rollout.

## Data shape
`images/{imageId}`:
```json
{
  "ownerUid": "firebase-auth-uid",
  "storagePath": "users/UID/images/IMAGE_ID",
  "downloadUrl": "https://...",
  "fileName": "photo.jpg",
  "contentType": "image/jpeg",
  "createdAt": "server timestamp",
  "updatedAt": "server timestamp",
  "deletedAt": null
}
```

## Scale notes
Firestore can hold millions of documents, but 10 million records require load tests,
cost monitoring, query/index review, retention policies, and carefully bounded fan-out.
Use cursor pagination; never load an entire collection. Firestore is not a general
full-text search engine: add a dedicated search service for production full-text search.

## Important
The rules are a secure starting point, not a substitute for a security review. Test
with the Firebase Emulator Suite. Do not put service-account credentials in the app.


## Added: Firestore post repository
`PostRepository` and `FirebasePostRepository` support creating, editing, deleting,
and cursor-paginating the signed-in user's posts. Page sizes are restricted to 1–100.
The repository enforces ownership checks client-side; Firestore rules remain the
authoritative security boundary.

## Added: Firebase Emulator tests
Install the test dependencies and run the emulator tests:
```bash
cd tests
npm install
cd ..
firebase emulators:exec --only firestore "npm --prefix tests run test:rules"
```
The test suite checks post create/update/delete ownership and image metadata reads.
It has been generated but has **not** been executed in this environment.
