const fs = require("node:fs");
const path = require("node:path");
const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails
} = require("@firebase/rules-unit-testing");
const { doc, setDoc, getDoc, updateDoc, deleteDoc } = require("firebase/firestore");

const PROJECT_ID = "social-midei-studio-test";
let testEnv;

before(async () => {
  const rules = fs.readFileSync(path.join(__dirname, "..", "firestore.rules"), "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules }
  });
});

beforeEach(async () => {
  await testEnv.clearFirestore();
});

after(async () => {
  await testEnv.cleanup();
});

describe("Firestore ownership and access rules", () => {
  it("allows an authenticated user to create their own post", async () => {
    const db = testEnv.authenticatedContext("alice").firestore();
    await assertSucceeds(setDoc(doc(db, "posts", "post-1"), {
      ownerUid: "alice",
      text: "Hello",
      imageUrls: [],
      createdAt: new Date()
    }));
  });

  it("rejects creating a post for another user", async () => {
    const db = testEnv.authenticatedContext("alice").firestore();
    await assertFails(setDoc(doc(db, "posts", "post-2"), {
      ownerUid: "bob",
      text: "Not mine",
      imageUrls: []
    }));
  });

  it("allows the owner to update their post", async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await setDoc(doc(ctx.firestore(), "posts", "post-3"), {
        ownerUid: "alice", text: "Before", imageUrls: []
      });
    });
    const db = testEnv.authenticatedContext("alice").firestore();
    await assertSucceeds(updateDoc(doc(db, "posts", "post-3"), { text: "After" }));
  });

  it("rejects another user updating or deleting a post", async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await setDoc(doc(ctx.firestore(), "posts", "post-4"), {
        ownerUid: "alice", text: "Owner post", imageUrls: []
      });
    });
    const db = testEnv.authenticatedContext("bob").firestore();
    await assertFails(updateDoc(doc(db, "posts", "post-4"), { text: "Hijack" }));
    await assertFails(deleteDoc(doc(db, "posts", "post-4")));
  });

  it("allows only the owner to read a private image metadata document", async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await setDoc(doc(ctx.firestore(), "images", "image-1"), {
        ownerUid: "alice",
        storagePath: "users/alice/profile/image-1",
        downloadUrl: "https://example.invalid/image"
      });
    });
    const alice = testEnv.authenticatedContext("alice").firestore();
    const bob = testEnv.authenticatedContext("bob").firestore();
    await assertSucceeds(getDoc(doc(alice, "images", "image-1")));
    await assertFails(getDoc(doc(bob, "images", "image-1")));
  });
});
